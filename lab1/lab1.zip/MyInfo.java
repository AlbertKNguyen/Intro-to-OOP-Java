// Albert Nguyen
// Albertnguyen@my.smccd.edu
// CIS 254ON 
// MyInfo.java
// My name and major information in text print
// Lab 1
// 6/19/17 
public class MyInfo {
   public static void main( String args[] ) {
      System.out.println("My name is Albert Nguyen"); 
      System.out.println("I am currently majoring in Electrical Engineering at Skyline College");
   }
}
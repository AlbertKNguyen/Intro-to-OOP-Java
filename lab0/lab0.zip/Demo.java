// Albert Nguyen
// Albertnguyen@my.smccd.edu
// CIS 254ON 
// Demo.java
// First Java program text print
// Lab 0
// 6/14/17 
public class Demo {
   public static void main( String args[] ) {
      System.out.println("Here is a java program"); 
      System.out.println("Written by Albert Nguyen");
   }
}
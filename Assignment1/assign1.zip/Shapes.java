// Albert Nguyen
// Albertnguyen@my.smccd.edu
// CIS 254ON 
// Shapes.java
// Print statements to display shapes with asterisks
// Assignment 1
// 6/22/17 
public class Shapes {
   public static void main( String args[] ) {
      System.out.println("Programmed by Albert Nguyen");    
      System.out.println("*********    ***     *       *"); // Top layer of the four different shapes of asterisks
      System.out.println("*       *   *   *   ***     * *");
      System.out.println("*       *  *     * *****   *   *");
      System.out.println("*       *  *     *   *    *     *");
      System.out.println("*       *  *     *   *   *       *");
      System.out.println("*       *  *     *   *    *     *");
      System.out.println("*       *  *     *   *     *   *");
      System.out.println("*       *   *   *    *      * *");
      System.out.println("*********    ***     *       *"); // Bottom layer of the four different shapes of asterisks
   }
}